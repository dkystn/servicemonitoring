<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$data['title'] = 'Login';
		$this->load->view('element/login.html',$data);
	}
	
	public function masuk_login2()
	{
		$username = $this->input->post("username");
		$password = $this->input->post("password");
			
		$cek = $this->model_login->cek_data_pengguna($username,md5($password));
		
        if(count($cek) == 1){ 
            foreach ($cek as $rows) {
				$id_user = $rows->id_user;
                $nama_user = $rows->nama_user;
				$level_pengguna = $rows->level_pengguna;
            }
			
            $this->session->set_userdata(array(
                'loginMasuk'		=> TRUE, 
				'id_user' 			=> $id_user,
				'nama_user' 		=> $nama_user,
				'level_pengguna' 	=> $level_pengguna
            ));
			if($this->session->userdata('level_pengguna')=='Admin'){
				redirect('admin');
			}else if ($this->session->userdata('level_pengguna')=='Pegawai'){
				redirect('beranda');
			}else {
				redirect('Pimpinan');
			}
		
		}else{
			$this->session->set_flashdata('pesan','<script>swal.fire("Gagal","Username atau password tidak ditemukan","error")</script>');
            redirect('login');
		}
	}
	public function masuk_login()
	{
		$username = $this->input->post("username");
		$password = $this->input->post("password");
			 
		$cek = $this->model_login->cek_data_pengguna($username, ($password));
		
		if(count($cek) == 1){ 
			foreach ($cek as $rows) {
				$id_user = $rows->id_user;
				$nama_user = $rows->nama_user;
				$level_pengguna = $rows->level_pengguna;
				$cabang = $rows->id_cabang; // Menambahkan variabel cabang
			}
			
			$this->session->set_userdata(array(
				'loginMasuk'        => TRUE, 
				'id_user'           => $id_user,
				'nama_user'         => $nama_user,
				'level_pengguna'    => $level_pengguna,
				'id_cabang'            => $cabang // Menyimpan cabang dalam session
			));

			if($this->session->userdata('level_pengguna') == 'Admin'){
				redirect('admin');
			} else if ($this->session->userdata('level_pengguna') == 'Pegawai'){
				redirect('beranda');
			} else if ($this->session->userdata('level_pengguna') == 'Pimpinan'){
				redirect('pimpinan');
			}
		} else {
			$pesan = '<script>swal.fire("Gagal","Username atau password tidak ditemukan","error")</script>';
			$this->session->set_flashdata('pesan', $pesan);
			redirect('login');
		}
		
	}

	public function keluar()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
	

}


