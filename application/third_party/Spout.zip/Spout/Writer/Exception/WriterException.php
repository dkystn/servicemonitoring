<?php

namespace Box\Spout\Writer\Exception;

use Box\Spout\Common\Exception\SpoutException;

/**
 * Class WriterException
 *
 * @abstract
 */
abstract class WriterException extends SpoutException
{
}
